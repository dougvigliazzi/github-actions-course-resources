#!/bin/bash
# https://duckduckgo.com/?q=act+%3A%3Aerror%3A%3AUnable+to+get+ACTIONS_RUNTIME_TOKEN+env+variable&atb=v373-1&ia=web
# https://github.com/nektos/act/issues/329

# rm -rf ~/.cache/act

# Stop when error
set -e

# live|staging
# Capture the ENVIRONMENT as an argument, otherwise set 'staging'
# Usage: ./act.sh live or ./act.sh staging
ENVIRONMENT=${1:-staging}

echo "Starting deployment to '$ENVIRONMENT' environment..."

# Open Docker Desktop if not running
open -a Docker

# Wait for Docker to be ready
while ! docker info >/dev/null 2>&1; do
    echo "Waiting for Docker to be ready..."
    sleep 1
done

echo "Docker is ready."

if [ ! -f ".act.vars.$ENVIRONMENT" ]; then
    echo "File '.act.vars.$ENVIRONMENT' not found!"
    exit 1
fi
cat './.act.vars' "./.act.vars.$ENVIRONMENT" > "./.vars.$ENVIRONMENT.tmp"

echo "Using .act.vars.$ENVIRONMENT and .act.vars files combined into .vars.$ENVIRONMENT.tmp"

echo "Starting act" 
time \
act push \
    --job deploy \
    --secret SSH_KEY="$(cat ~/.ssh/id_rsa)" \
    --secret SSH_CONFIG_TPP_LIVE="$(cat ./.ssh_config_live_dt)" \
    --secret SSH_CONFIG_TPP_STG_PREMIUM="$(cat ./.ssh_config_stg_dt)" \
    --secret TPP_STG_LIVE_TEST_ENV_FILE_CONTENT="'$(cat ./.env.live.dt)'" \
    --secret TPP_STG_PREMIUM_TEST_ENV_FILE_CONTENT="'$(cat ./.env.staging.dt)'" \
    --var CYPRESS_TESTS_CONFIG="'$(cat ./.cypress.config.json)'" \
    --var-file ".vars.$ENVIRONMENT.tmp" \
    --workflows "../.github/workflows/workflow-deploy-$ENVIRONMENT.yml" \
| ts '[%Y-%m-%d %H:%M:%S]'
    # --action-offline-mode \
    # --secret-file .secrets \
    # --verbose \

rm ".vars.$ENVIRONMENT.tmp"
